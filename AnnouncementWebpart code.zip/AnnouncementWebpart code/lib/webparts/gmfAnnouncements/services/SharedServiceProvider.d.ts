import { ISharedServiceProvider } from './ISharedServiceProvider';
import { IAnnouncements } from "../../gmfAnnouncements/services/Announcements";
import { ServiceKey, ServiceScope } from '@microsoft/sp-core-library';
export declare class SharedServiceProvider implements ISharedServiceProvider {
    static readonly serviceKey: ServiceKey<ISharedServiceProvider>;
    private _spHttpClient;
    private _pageContext;
    private _currentWebUrl;
    constructor(serviceScope: ServiceScope);
    getAnnouncements(): Promise<IAnnouncements>;
    logCurrentEnvironment(): String;
}
//# sourceMappingURL=SharedServiceProvider.d.ts.map