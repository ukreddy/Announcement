import { ISharedServiceProvider } from './ISharedServiceProvider';
import { IAnnouncements } from "../announcement/Announcements";
export declare class MockServiceProvider implements ISharedServiceProvider {
    constructor();
    private static mockAnnouncements;
    getAnnouncements(): Promise<IAnnouncements>;
    logCurrentEnvironment(): String;
}
//# sourceMappingURL=MockServiceProvider.d.ts.map