import * as React from 'react';
import { IGmfAnnouncementsProps } from './IGmfAnnouncementsProps';
import { IGmfAnnouncementsState } from './IGmfAnnouncementsState';
export default class GmfAnnouncements extends React.Component<IGmfAnnouncementsProps, IGmfAnnouncementsState> {
    private _sharedService;
    constructor(props: IGmfAnnouncementsProps);
    componentDidMount(): void;
    render(): React.ReactElement<IGmfAnnouncementsProps>;
    private GetAnnouncements;
}
//# sourceMappingURL=GmfAnnouncements.d.ts.map