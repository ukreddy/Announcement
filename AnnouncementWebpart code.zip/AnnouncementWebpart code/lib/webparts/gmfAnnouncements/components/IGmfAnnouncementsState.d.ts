import { IAnnouncement } from '../../gmfAnnouncements/services/Announcements';
export interface IGmfAnnouncementsState {
    Announcements: IAnnouncement[];
}
//# sourceMappingURL=IGmfAnnouncementsState.d.ts.map