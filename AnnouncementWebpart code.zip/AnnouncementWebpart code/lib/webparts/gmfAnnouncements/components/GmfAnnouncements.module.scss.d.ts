declare const styles: {
    announcements: string;
    titleblock: string;
    btn: string;
    announcementsList: string;
    announcementIcon: string;
    txt: string;
};
export default styles;
//# sourceMappingURL=GmfAnnouncements.module.scss.d.ts.map