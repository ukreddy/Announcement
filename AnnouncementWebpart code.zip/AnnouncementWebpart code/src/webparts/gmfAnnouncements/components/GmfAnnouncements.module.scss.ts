/* tslint:disable */
require("./GmfAnnouncements.module.css");
const styles = {
  announcements: 'announcements_043bb005',
  titleblock: 'titleblock_043bb005',
  btn: 'btn_043bb005',
  announcementsList: 'announcementsList_043bb005',
  announcementIcon: 'announcementIcon_043bb005',
  txt: 'txt_043bb005'
};

export default styles;
/* tslint:enable */