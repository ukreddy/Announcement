import { WebPartContext } from "@microsoft/sp-webpart-base";

export interface IGmfAnnouncementsProps {
  title: string;
  userDisplayName: string;
  context: WebPartContext;
}
