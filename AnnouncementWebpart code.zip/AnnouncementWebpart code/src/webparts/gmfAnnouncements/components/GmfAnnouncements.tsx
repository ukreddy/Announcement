import * as React from 'react';
import styles from './GmfAnnouncements.module.scss';
import { IGmfAnnouncementsProps } from './IGmfAnnouncementsProps';
//import { escape } from '@microsoft/sp-lodash-subset';
import { IGmfAnnouncementsState } from './IGmfAnnouncementsState';
import { IAnnouncements } from './Announcements';
import { ISharedServiceProvider } from '../services/ISharedServiceProvider';
import { SharedServiceProvider } from '../services/SharedServiceProvider';

export default class GmfAnnouncements extends React.Component<IGmfAnnouncementsProps, IGmfAnnouncementsState> {

  private _sharedService: ISharedServiceProvider;
  constructor(props: IGmfAnnouncementsProps) {
    super(props);
    //this._spServices = new SharedServiceProvider(this.props.context);
    this.state = {
      Announcements: []
    };
  }
  public componentDidMount(): void {
    this.GetAnnouncements();
  }
  public render(): React.ReactElement<IGmfAnnouncementsProps> {
  
    //let announcementLogo: string = String(require('./images/Announcement.png'));
    if(this.state.Announcements.length>0){
    return (
      
        <div className={`${styles.announcements} `}>
            {this.state.Announcements.map((item) => {
            
              return (
                
          <ul className={`${styles.announcementsList} `}>
              <li>    
                <div className={`${styles.announcementIcon} `}>
                <img src={require('../images/Announcement.jpg')} />
                </div>        
                  <div className={`${styles.txt} `}>
                    <h2>{item.Title}</h2>
                    <p>{item.Body}</p>
                  </div>            
              </li>
          </ul>
      )
        })}
        </div>
     
    );
      }
      else{
        return  <div className={`${styles.announcements} `}>No service outage.</div>
      }
  }

  private async GetAnnouncements() {
    this._sharedService =  this.props.context.serviceScope.consume(SharedServiceProvider.serviceKey);
    this._sharedService.getAnnouncements().then((response: IAnnouncements) => {
      this.setState({Announcements:response.value});
      
    }).catch((err) => {
      console.log('Error getting announcements : ' + err);
    });
  }
}
