import { IAnnouncements } from "../../gmfAnnouncements/services/Announcements";
export interface ISharedServiceProvider {
    getAnnouncements(): Promise<IAnnouncements>;
    logCurrentEnvironment():String ;
}