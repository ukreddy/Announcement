export interface IAnnouncements{
    value: IAnnouncement[];
}


export interface IAnnouncement{
    Id:string;
    Title:string;
    Body:string;
}